
var gyro = {
  handleMotionEvent:function(event){
  	this.x.innerHTML  = gyro.setText(event.accelerationIncludingGravity.x.toFixed(4));
  	this.y.innerHTML  = gyro.setText(event.accelerationIncludingGravity.y.toFixed(4));
  	this.z.innerHTML  = gyro.setText(event.accelerationIncludingGravity.z.toFixed(4));
  	this.x2.innerHTML = gyro.setText(event.acceleration.x.toFixed(4));
  	this.y2.innerHTML = gyro.setText(event.acceleration.y.toFixed(4));
  	this.z2.innerHTML = gyro.setText(event.acceleration.z.toFixed(4));

  	if(this.trigger){
  		if(this.second%2==0 && !this.st){
  			this.st = true;
  			this.magicZ[this.second/2] = [event.acceleration.z.toFixed(4),event.interval];
  			this.st = false;
  		}
  	}
  },
  start:function(){
    if(this.trigger==false){
       this.trigger = true;
       this.myVar = setInterval(this.myTimer ,500);
    }
  },
  stop:function(){
    if(this.trigger==true){
       $('#hahaha').html(JSON.stringify(this.magicZ));
       clearInterval(this.myVar);
       this.second = 0;
       this.magicZ = [];
       this.trigger= false;
    }
  },
  myTimer:function(){
    this.second++;
    document.getElementById('time').innerHTML = this.second;
  },
  init:function(){
      this.trigger = false;
      this.magicZ  = [];
      this.second  = 0;
      this.st      = false;
      this.x = document.getElementById('x');
      this.y = document.getElementById('y');
      this.z = document.getElementById('z');
      this.x2= document.getElementById('x2');
      this.y2= document.getElementById('y2');
      this.y3= document.getElementById('z2')
      this.a = document.getElementById('alpha');
      this.b = document.getElementById('beta');
      this.g = document.getElementById('gamma');
  },
  getColor:function(input){
    var text = 'color:#0000ff;';
    // if(input>0.000){
    //   text = 'color:#00ff00;';
    // }
    // else if(input<0.000){
    //   text = 'color:#ff0000;';
    // }
    // else{
    //   text = 'color:#0000ff;';
    // }
    return text;
  },
  setText:function(input){
    return '<label style="'+this.getColor(input)+'">'+input+'</label>';
  }
};


document.addEventListener('deviceready', function(){
  gyro.init();
  if(window.DeviceOrientationEvent) {
  	 window.addEventListener('deviceorientation', function(event) {
  			gyro.a.innerHTML = gyro.setText(event.webkitCompassHeading.toFixed(4));
  			gyro.b.innerHTML = gyro.setText(event.beta.toFixed(2));
  			gyro.g.innerHTML = gyro.setText(event.gamma.toFixed(2));
  		},false);
  }
  else{
    console.log('not supported');
  }
  window.addEventListener("devicemotion", gyro.handleMotionEvent, true);
}, false);
